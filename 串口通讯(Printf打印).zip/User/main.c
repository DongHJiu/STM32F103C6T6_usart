#include "stm32f10x.h"                  // Device header
#include "USART.h"
#include "Delay.h"
#include "LED.h"


u16 i = 0;

int main(void){
	LED_Init();
	Usart1_Init(9600);
	while(1){
		LED_Data(1);
    UsartPrintf(USART1,"Time = %d\n",i);
		Delay_ms(1000);
		i++;
	}
}
