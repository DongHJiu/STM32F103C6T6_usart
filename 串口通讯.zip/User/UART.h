#ifndef __USAR_H
#define __USAR_H

extern u8 Data;

void UART_Init(void);
void NVIC_USART1(void);



#endif
