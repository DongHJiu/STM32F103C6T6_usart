#include "stm32f10x.h"                  // Device header
#include "UART.h"
#include "Delay.h"
#include "LED.h"


int main(void){
	UART_Init();
	NVIC_USART1();
	LED_Init();
	while(1){
		LED_Data(1);
	}
}
