#include "stm32f10x.h"                  // Device header
#include "UART.h"
#include "Delay.h"
#include "LED.h"


int main(void){
	LED_Init();
	UART_Init();
  NVIC_USART1();
	while(1){
		LED_Data(1);
    USART1_Str("�´�");
		Delay_ms(1000);
	}
}
